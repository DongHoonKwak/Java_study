//���α׷��� : ���� �̿��� ��ȣ�� ��ٰ��� ����ϱ�
//�й��̸� : 2014041028 ������
//��¥ : 2017.11.3
package seggse;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class DrawString7 extends JFrame {

   private MyPanel contentPane=new MyPanel();

   public DrawString7() {
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setBounds(100, 100, 450, 300);
      contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
      contentPane.setLayout(new BorderLayout(0, 0));
      setContentPane(contentPane);
      setSize(500, 500);
      setVisible(true);
   }
   
   class MyPanel extends JPanel {
	   public void paintComponent(Graphics g) {
		   super.paintComponent(g);
		   g.setColor(Color.RED);
		   g.drawArc(20,100,80,80,90,270);
		   int[]x = {80,40,80,120};
		   int[]y = {40,120,200,120};
		   g.drawPolygon(x, y, 4);
		   }
	   
   }
   public static void main(String[] args) {
	      
	      new DrawString7();
	   }

}