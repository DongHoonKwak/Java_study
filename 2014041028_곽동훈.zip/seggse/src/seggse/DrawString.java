// ���α׷��� : ���� �ⷰ�ϱ�
//�й��̸� : 2014041028 ������
//��¥ : 2017.11.3
package seggse;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class DrawString extends JFrame {

   private MyPanel contentPane=new MyPanel();

   /**
    * Launch the application.
    */
   public static void main(String[] args) {
      
      new DrawString();
   }

   /**
    * Create the frame.
    */
   public DrawString() {
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setBounds(100, 100, 450, 300);
      contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
      contentPane.setLayout(new BorderLayout(0, 0));
      setContentPane(contentPane);
      setSize(1000, 1000);
      setVisible(true);
   }
   
   class MyPanel extends JPanel {
      private ImageIcon icon = new ImageIcon("awdsd.jpg");
      private Image img = icon.getImage();
      public void paintComponent(Graphics g) {
         super.paintComponent(g);
        // g.drawImage(img, 20, 20, this);
        g.drawImage(img, 0, 0, getWidth(), getHeight(), this);
         //g.drawImage(img, 20,20,500,300,100,50,200,200,this);
      }
   }

}