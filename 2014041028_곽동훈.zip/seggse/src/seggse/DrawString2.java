// ���α׷��� : �۾� ����ϱ�
//�й��̸� : 2014041028 ������
//��¥ : 2017.11.3
package seggse;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class DrawString2 extends JFrame {

   private MyPanel contentPane=new MyPanel();

   public DrawString2() {
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setBounds(100, 100, 450, 300);
      contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
      contentPane.setLayout(new BorderLayout(0, 0));
      setContentPane(contentPane);
      setSize(500, 500);
      setVisible(true);
   }
   
   class MyPanel extends JPanel {
	   public void paintComponent(Graphics g) {
		   super.paintComponent(g);
		   g.drawString("�ڹٴ���մ�.~~", 30,30);
		   g.drawString("�󸶳�? �ϴø�ŭ����ŭ!!!!", 60, 60);
		   }
   }
   public static void main(String[] args) {
	      
	      new DrawString2();
	   }

}